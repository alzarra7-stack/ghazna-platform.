'use strict';
// منصة غازنا: خادم Node.js بلا أي مكتبات خارجية. التشغيل: node server.js
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = +process.env.PORT || 3000;
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'db.json');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
if (ADMIN_PASSWORD.length < 8) { console.error('ضع ADMIN_PASSWORD (8 أحرف فأكثر) في متغيرات البيئة'); process.exit(1); }
const PUB = path.join(__dirname, 'public');

let db = { users: [], merchants: [], orders: [], reviews: [], photos: [], plans: { monthly: 99, yearly: 990 }, sessions: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); } catch (e) { /* قاعدة جديدة */ }
let timer = null;
const save = () => { clearTimeout(timer); timer = setTimeout(() => {
  fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
  const tmp = DB_FILE + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(db)); fs.renameSync(tmp, DB_FILE); }, 50); };

const rid = () => crypto.randomBytes(8).toString('hex');
const hashPw = (pw, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, h: crypto.scryptSync(pw, salt, 64).toString('hex') });
const checkPw = (pw, o) => { const a = Buffer.from(crypto.scryptSync(pw, o.salt, 64).toString('hex')), b = Buffer.from(o.h); return a.length === b.length && crypto.timingSafeEqual(a, b); };
const sha = s => crypto.createHash('sha256').update(String(s)).digest();
const str = (v, n = 200) => typeof v === 'string' ? v.trim().slice(0, n) : '';
const num = (v, d = 0) => Number.isFinite(+v) ? +v : d;
const fail = (code, msg) => { const e = new Error(msg); e.code = code; throw e; };
const phoneOK = p => /^05\d{8}$/.test(p);
const imgOK = d => typeof d === 'string' && /^data:image\/(png|jpe?g|webp);base64,/.test(d) && d.length < 1.5e6;
const tries = {};
const limited = ip => { const n = Date.now(); const a = (tries[ip] = (tries[ip] || []).filter(x => n - x < 9e5)); a.push(n); return a.length > 10; };

const newSession = (role, uid) => { const tk = crypto.randomBytes(24).toString('hex'); db.sessions[tk] = { role, uid, exp: Date.now() + 24 * 36e5 }; save(); return tk; };
const auth = req => { const m = /^Bearer (.+)$/.exec(req.headers.authorization || ''); const s = m && db.sessions[m[1]];
  if (!s) return null; if (s.exp < Date.now()) { delete db.sessions[m[1]]; return null; } return s; };
const need = (req, ...roles) => { const s = auth(req); if (!s) fail(401, 'سجّل الدخول أولًا'); if (!roles.includes(s.role)) fail(403, 'غير مسموح'); return s; };

const userView = u => ({ id: u.id, name: u.name, phone: u.phone, email: u.email, city: u.city, district: u.district, lat: u.lat, lng: u.lng });
const rating = id => { const r = db.reviews.filter(x => x.m === id); return { rating: r.length ? +(r.reduce((s, x) => s + x.stars, 0) / r.length).toFixed(1) : 0, ratings: r.length }; };
const merView = (m, priv) => { const v = { id: m.id, name: m.name, city: m.city, district: m.district, lat: m.lat, lng: m.lng, price: m.price, phone: m.phone, plan: m.plan, ...rating(m.id) };
  if (priv) Object.assign(v, { owner: m.owner, email: m.email, status: m.status, cr: m.cr, planUntil: m.planUntil }); return v; };
const isLive = m => m.status === 'active' && m.plan && m.planUntil > Date.now();
const orderView = o => ({ ...o, reviewed: db.reviews.some(r => r.oid === o.id) });

function profile(target, b, role) {
  for (const k of ['name', 'email', 'city', 'district']) if (b[k] !== undefined) target[k] = str(b[k], 80);
  if (b.lat !== undefined && b.lng !== undefined) { const la = num(b.lat, NaN), ln = num(b.lng, NaN);
    if (la >= -90 && la <= 90 && ln >= -180 && ln <= 180) { target.lat = la; target.lng = ln; } }
  if (role === 'merchant') {
    if (b.owner !== undefined) target.owner = str(b.owner, 80);
    if (b.price !== undefined) { const p = num(b.price); if (p > 0 && p < 1000) target.price = p; }
    if (b.cr) { if (!imgOK(b.cr)) fail(400, 'صورة السجل غير صالحة أو كبيرة'); target.cr = b.cr; }
  }
}

const readBody = req => new Promise((ok, no) => { let b = '', n = 0;
  req.on('data', c => { n += c.length; if (n > 6e6) { no(Object.assign(new Error('الطلب كبير'), { code: 413 })); req.destroy(); } else b += c; });
  req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(Object.assign(new Error('JSON غير صالح'), { code: 400 })); } });
  req.on('error', no); });
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };

async function api(req, res, u) {
  const p = u.pathname, m = req.method, ip = req.socket.remoteAddress;
  const b = ['POST', 'PUT', 'PATCH'].includes(m) ? await readBody(req) : {};
  let r;
  if (p === '/api/health') return send(res, 200, { ok: true });
  if (p === '/api/public' && m === 'GET')
    return send(res, 200, { merchants: db.merchants.filter(isLive).map(x => merView(x)), reviews: db.reviews.filter(x => x.site).map(({ by, stars, text }) => ({ by, stars, text })), photos: db.photos, plans: db.plans });

  if (p === '/api/register' && m === 'POST') {
    if (limited(ip)) fail(429, 'محاولات كثيرة، حاول لاحقًا');
    const role = b.role, phone = str(b.phone, 10), pw = str(b.password, 100), name = str(b.name, 80);
    if (!['user', 'merchant'].includes(role)) fail(400, 'نوع الحساب غير صحيح');
    if (!phoneOK(phone)) fail(400, 'رقم الجوال يجب أن يكون بصيغة 05xxxxxxxx');
    if (pw.length < 8) fail(400, 'كلمة المرور 8 أحرف على الأقل');
    if (!name) fail(400, 'الاسم مطلوب');
    const list = role === 'user' ? db.users : db.merchants;
    if (list.some(x => x.phone === phone)) fail(409, 'رقم الجوال مسجل مسبقًا');
    const rec = { id: rid(), phone, name, email: '', city: '', district: '', lat: null, lng: null, created: Date.now(), pw: hashPw(pw) };
    if (role === 'merchant') Object.assign(rec, { owner: '', price: 18, plan: null, planUntil: 0, status: 'pending', cr: null });
    profile(rec, b, role); rec.phone = phone; list.push(rec); save();
    return send(res, 201, { token: newSession(role, rec.id), role });
  }
  if (p === '/api/login' && m === 'POST') {
    if (limited(ip)) fail(429, 'محاولات كثيرة، حاول بعد 15 دقيقة');
    if (b.role === 'admin') { if (!crypto.timingSafeEqual(sha(b.password), sha(ADMIN_PASSWORD))) fail(401, 'بيانات غير صحيحة'); return send(res, 200, { token: newSession('admin', 'admin'), role: 'admin' }); }
    const list = b.role === 'user' ? db.users : b.role === 'merchant' ? db.merchants : fail(400, 'نوع الحساب غير صحيح');
    const rec = list.find(x => x.phone === str(b.phone, 10));
    if (!rec || !checkPw(str(b.password, 100), rec.pw)) fail(401, 'بيانات غير صحيحة');
    return send(res, 200, { token: newSession(b.role, rec.id), role: b.role });
  }
  if (p === '/api/logout' && m === 'POST') { const mm = /^Bearer (.+)$/.exec(req.headers.authorization || ''); if (mm) { delete db.sessions[mm[1]]; save(); } return send(res, 200, { ok: true }); }

  if (p === '/api/me') {
    const s = need(req, 'user', 'merchant');
    const rec = (s.role === 'user' ? db.users : db.merchants).find(x => x.id === s.uid); if (!rec) fail(404, 'الحساب غير موجود');
    if (m === 'PUT') { profile(rec, b, s.role); save(); }
    return send(res, 200, s.role === 'user' ? userView(rec) : merView(rec, true));
  }

  if (p === '/api/subscribe' && m === 'POST') {
    const s = need(req, 'merchant'); const rec = db.merchants.find(x => x.id === s.uid);
    if (!['monthly', 'yearly'].includes(b.plan)) fail(400, 'الباقة غير صحيحة');
    // ملاحظة: اربط هنا بوابة الدفع (Moyasar/HyperPay) وفعّل الباقة بعد تأكيد الدفع فقط
    rec.plan = b.plan; rec.planUntil = Date.now() + (b.plan === 'yearly' ? 365 : 30) * 864e5; save();
    return send(res, 200, merView(rec, true));
  }

  if (p === '/api/orders' && m === 'POST') {
    const s = need(req, 'user'); const u1 = db.users.find(x => x.id === s.uid);
    const mer = db.merchants.find(x => x.id === b.merchantId);
    if (!mer || !isLive(mer)) fail(400, 'التاجر غير متاح');
    if (u1.lat == null || !u1.city) fail(400, 'أكمل عنوانك وموقعك على الخريطة أولًا');
    const fresh = b.item === 1 || b.item === '1', qty = Math.round(num(b.qty, 1));
    if (qty < 1 || qty > 20) fail(400, 'الكمية غير صحيحة');
    if (!['cash', 'card'].includes(b.pay)) fail(400, 'طريقة الدفع غير صحيحة');
    const o = { id: rid(), m: mer.id, uid: u1.id, item: fresh ? 'اسطوانة جديدة 12 كجم' : 'استبدال اسطوانة 12 كجم', qty, total: (mer.price + (fresh ? 150 : 0)) * qty,
      pay: b.pay, paid: false, st: 'c', by: u1.name, phone: u1.phone, addr: u1.city + '، ' + u1.district, lat: u1.lat, lng: u1.lng, at: Date.now() };
    db.orders.unshift(o); save(); return send(res, 201, o);
  }
  if (p === '/api/orders' && m === 'GET') {
    const s = need(req, 'user', 'merchant', 'admin');
    return send(res, 200, db.orders.filter(o => s.role === 'admin' || (s.role === 'user' ? o.uid === s.uid : o.m === s.uid)).map(orderView));
  }
  if ((r = /^\/api\/orders\/(\w+)$/.exec(p)) && m === 'PATCH') {
    const s = need(req, 'user', 'merchant', 'admin'); const o = db.orders.find(x => x.id === r[1]);
    if (!o || (s.role === 'user' && o.uid !== s.uid) || (s.role === 'merchant' && o.m !== s.uid)) fail(404, 'الطلب غير موجود');
    const next = { c: ['a', 'x'], a: ['o'], o: ['d'] }[o.st] || [];
    const ok = s.role === 'admin' ? ['c', 'a', 'o', 'd', 'x'].includes(b.status) : s.role === 'user' ? (o.st === 'c' && b.status === 'x') : next.includes(b.status);
    if (!ok) fail(400, 'تغيير الحالة غير مسموح'); o.st = b.status; if (b.status === 'd' && o.pay === 'cash') o.paid = true; save(); return send(res, 200, o);
  }
  if (p === '/api/reviews' && m === 'POST') {
    const s = need(req, 'user'); const o = db.orders.find(x => x.id === b.orderId && x.uid === s.uid);
    if (!o || o.st !== 'd') fail(400, 'يمكن التقييم بعد التسليم فقط');
    if (db.reviews.some(x => x.oid === o.id)) fail(409, 'تم تقييم هذا الطلب');
    const stars = Math.round(num(b.stars)); if (stars < 1 || stars > 5) fail(400, 'التقييم من 1 إلى 5');
    db.reviews.push({ id: rid(), oid: o.id, m: o.m, by: o.by, stars, text: str(b.text, 500), site: false, at: Date.now() }); save(); return send(res, 201, { ok: true });
  }
  if (p === '/api/merchant/reviews' && m === 'GET') { const s = need(req, 'merchant'); return send(res, 200, db.reviews.filter(x => x.m === s.uid).map(({ by, stars, text, at }) => ({ by, stars, text, at }))); }

  /* ---- الإدارة ---- */
  if (p.startsWith('/api/admin/')) {
    need(req, 'admin');
    if (p === '/api/admin/all' && m === 'GET') return send(res, 200, { merchants: db.merchants.map(x => merView(x, true)), users: db.users.map(userView), orders: db.orders, reviews: db.reviews, photos: db.photos, plans: db.plans });
    if ((r = /^\/api\/admin\/merchants\/(\w+)$/.exec(p))) { const x = db.merchants.find(y => y.id === r[1]); if (!x) fail(404, 'غير موجود');
      if (m === 'PATCH') { if (!['active', 'pending', 'suspended'].includes(b.status)) fail(400, 'حالة غير صحيحة'); x.status = b.status; save(); return send(res, 200, merView(x, true)); }
      if (m === 'DELETE') { db.merchants = db.merchants.filter(y => y !== x); save(); return send(res, 200, { ok: true }); } }
    if ((r = /^\/api\/admin\/users\/(\w+)$/.exec(p)) && m === 'DELETE') { db.users = db.users.filter(y => y.id !== r[1]); save(); return send(res, 200, { ok: true }); }
    if (p === '/api/admin/reviews' && m === 'POST') { const stars = Math.round(num(b.stars, 5)); if (!str(b.by) || !str(b.text) || stars < 1 || stars > 5) fail(400, 'بيانات ناقصة');
      db.reviews.push({ id: rid(), oid: null, m: 0, by: str(b.by, 80), stars, text: str(b.text, 500), site: true, at: Date.now() }); save(); return send(res, 201, { ok: true }); }
    if ((r = /^\/api\/admin\/reviews\/(\w+)$/.exec(p))) { const x = db.reviews.find(y => y.id === r[1]); if (!x) fail(404, 'غير موجود');
      if (m === 'PATCH') { x.site = !!b.site; save(); return send(res, 200, x); }
      if (m === 'DELETE') { db.reviews = db.reviews.filter(y => y !== x); save(); return send(res, 200, { ok: true }); } }
    if (p === '/api/admin/photos' && m === 'POST') { if (!imgOK(b.data)) fail(400, 'صورة غير صالحة'); if (db.photos.length >= 30) fail(400, 'الحد الأقصى 30 صورة'); db.photos.push(b.data); save(); return send(res, 201, { count: db.photos.length }); }
    if ((r = /^\/api\/admin\/photos\/(\d+)$/.exec(p)) && m === 'DELETE') { db.photos.splice(+r[1], 1); save(); return send(res, 200, { ok: true }); }
    if (p === '/api/admin/plans' && m === 'PUT') { const a = num(b.monthly), y = num(b.yearly); if (a < 1 || y < 1) fail(400, 'سعر غير صحيح'); db.plans = { monthly: a, yearly: y }; save(); return send(res, 200, db.plans); }
  }
  fail(404, 'المسار غير موجود');
}

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'SAMEORIGIN'); res.setHeader('Referrer-Policy', 'same-origin');
  const u = new URL(req.url, 'http://x');
  if (u.pathname.startsWith('/api/')) { try { await api(req, res, u); } catch (e) { send(res, e.code || 500, { error: e.code ? e.message : 'خطأ في الخادم' }); if (!e.code) console.error(e); } return; }
  let f = path.normalize(decodeURIComponent(u.pathname)).replace(/^(\.\.[/\\])+/, ''); if (f === path.sep || f === '.') f = 'index.html';
  const full = path.join(PUB, f);
  if (!full.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.readFile(full, (err, data) => { if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('الصفحة غير موجودة'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(full)] || 'application/octet-stream', 'Cache-Control': 'no-cache' }); res.end(data); });
}).listen(PORT, () => console.log('غازنا يعمل على المنفذ ' + PORT));
